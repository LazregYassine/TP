package sync;

public class SyncCounter {
    public void increment() {
    }

    public void decrement() {
    }
}
